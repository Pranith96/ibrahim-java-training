package com.employee.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	//http://localhost:8080/employees/hello
	@GetMapping("/hello")
	public String hello() {
		return "Hello, Employee Management!";
	}
	
	//http://localhost:8080/employees/hi
	@GetMapping("/hi")
	public String hi() {
		return "Hi, Welcome";
	}
	
	@GetMapping
	public String display() {
		return "Hi, display";
	}
}
